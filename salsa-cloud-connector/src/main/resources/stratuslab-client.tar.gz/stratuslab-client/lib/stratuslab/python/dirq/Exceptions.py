class QueueError(Exception):
    ''

class QueueLockError(QueueError):
    ''
