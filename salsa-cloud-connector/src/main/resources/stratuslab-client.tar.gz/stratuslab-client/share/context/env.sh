#!/bin/bash

export STRATUSLAB_ENDPOINT=http://localhost:2633/RPC2
export STRATUSLAB_USERNAME=oneadmin
export STRATUSLAB_PASSWORD=oneadmin
export STRATUSLAB_LOCATION=/tmp/stratuslab-remote-install
