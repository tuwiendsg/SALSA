java -cp 'bootstrap_container-0.0.1-SNAPSHOT-jar-with-dependencies.jar:*' at.ac.tuwien.infosys.bootstrapcontainer.Main > sensor.out 2>&1 &
echo $!>sensor.pid
