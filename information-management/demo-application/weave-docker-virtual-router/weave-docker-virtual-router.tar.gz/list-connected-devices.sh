/usr/local/bin/weave ps
