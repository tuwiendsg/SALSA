/usr/local/bin/weave connect $1
