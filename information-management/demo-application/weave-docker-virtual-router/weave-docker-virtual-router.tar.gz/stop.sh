/usr/local/bin/weave stop
