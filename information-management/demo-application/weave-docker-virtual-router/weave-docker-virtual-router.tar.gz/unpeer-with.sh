/usr/local/bin/weave forget $1
